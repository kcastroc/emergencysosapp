package karen.androidatc.emergencyapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_register.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.main,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        var selectedOption = ""

        when(item?.itemId){

            R.id.settings -> selectedOption = "Settings"
            R.id.help -> selectedOption = "Help"
            R.id.item_1 -> selectedOption = "Profile"
            R.id.item_2 -> selectedOption = "SOS Button"
            R.id.item_3 -> selectedOption = "Emergency Contacts"
        }

        Toast.makeText(this, "Option : " + selectedOption,Toast.LENGTH_SHORT).show()

        return super.onOptionsItemSelected(item)
    }

    fun sendMessage(view: View) {}
}